from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
from sklearn.naive_bayes import BernoulliNB
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, precision_score, recall_score, f1_score
import math

# Load data
def load_data():
    train_matrix = np.loadtxt('2Newsgroups/trainMatrixModified.txt').T  # Transpose to have documents as rows and terms as columns

    # Load trainClasses
    train_classes = np.zeros(train_matrix.shape[0], dtype=int)
    with open('2Newsgroups/trainClasses.txt') as f:
        for line in f:
            doc_index, class_id = line.strip().split('\t')
            train_classes[int(doc_index)] = int(class_id)

    test_matrix = np.loadtxt('2Newsgroups/testMatrixModified.txt').T  # Transpose to have documents as rows and terms as columns
    # Load testClasses
    test_classes = np.zeros(test_matrix.shape[0], dtype=int)
    with open('2Newsgroups/testClasses.txt') as f:
        for line in f:
            doc_index, class_id = line.strip().split('\t')
            test_classes[int(doc_index)] = int(class_id)
    

    return train_matrix, train_classes, test_matrix, test_classes

# Manual Implementation of Naive Bayes Multivariate Bernoulli
def train_bernoulli_nb(train_matrix, train_classes):
    N = train_matrix.shape[0]
    V = train_matrix.shape[1]
    classes = np.unique(train_classes)
    priors = {}
    condprob = defaultdict(lambda: defaultdict(float))

    for c in classes:
        Nc = np.sum(train_classes == c)
        priors[c] = Nc / N
        for t in range(V):
            Dct = np.sum(train_matrix[train_classes == c, t])
            condprob[t][c]= (Dct + 1) / (Nc + 2)
    
    return priors, condprob

def apply_bernoulli_nb(document, priors, condprob):
    classes = list(priors.keys())
    scores = {}
    for c in classes:
        scores[c] = math.log(priors[c])
        for t in range(len(document)):
            prob = condprob[t][c]
            prob = min(max(prob, 1e-10), 1 - 1e-10)  # Clamp values to avoid log(0)
            if document[t] > 0:
                scores[c] += math.log(prob)
            else:
                scores[c] += math.log(1 - prob)
    return max(scores, key=scores.get)

# Train and evaluate manual implementation
def evaluate_manual_nb(train_matrix, train_classes, test_matrix, test_classes):
    priors, condprob = train_bernoulli_nb(train_matrix, train_classes)
    predictions = [apply_bernoulli_nb(test_matrix[i, :], priors, condprob) for i in range(test_matrix.shape[0])]
    accuracy = accuracy_score(test_classes, predictions)
    conf_matrix = confusion_matrix(test_classes, predictions)
    precision = precision_score(test_classes,predictions)
    recall = recall_score(test_classes, predictions)
    f1 = f1_score(test_classes, predictions)
    return accuracy, conf_matrix, precision, recall, f1

# Train and evaluate scikit-learn implementation
def evaluate_sklearn_nb(train_matrix, train_classes, test_matrix, test_classes):
    model = BernoulliNB()
    model.fit(train_matrix, train_classes)
    predictions = model.predict(test_matrix)
    accuracy = accuracy_score(test_classes, predictions)
    conf_matrix = confusion_matrix(test_classes, predictions)
    precision = precision_score(test_classes, predictions)
    recall = recall_score(test_classes, predictions)
    f1 = f1_score(test_classes, predictions)
    return accuracy, conf_matrix, precision,recall,f1

# Plot confusion matrix
def plot_confusion_matrix(cm, title):
    plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(2)
    plt.xticks(tick_marks, ['Windows', 'Hockey'], rotation=45)
    plt.yticks(tick_marks, ['Windows', 'Hockey'])
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.savefig(f"{title}.png")

def plot_results(scores, label):
    labels = ['Precision', 'Recall', 'F1-score', 'Accuracy']
    plt.figure(figsize=(8, 6))
    plt.plot(labels, scores, marker='o', linestyle='-')
    plt.xlabel('Metric')
    plt.ylabel('Score')
    plt.title(f'{label} Evaluation Metrics')
    plt.ylim(0, 1)  
    plt.savefig(f'{label} Evaluation Metrics')

def write_scores_to_file(accuracy,precision,recall, f1,cm,filename):
  with open(filename, "w+") as f:
    f.write("Accuracy: {}\n".format(accuracy))
    f.write("Precision: {}\n".format(precision))
    f.write("Recall: {}\n".format(recall))
    f.write("F1: {}\n".format(f1))
    f.write("Confusion Matrix:\n")
    f.write("{} {}\n".format(cm[0][0],cm[0][1]))
    f.write("{} {}".format(cm[1][0],cm[1][1]))
# Main function
def main():
    train_matrix, train_classes, test_matrix, test_classes = load_data()

    # Manual Naive Bayes
    manual_accuracy, manual_conf_matrix, manual_precision, manual_recall,manual_f1 = evaluate_manual_nb(train_matrix, train_classes, test_matrix, test_classes)
    # print("Manual Naive Bayes Accuracy:", manual_accuracy)
    plot_confusion_matrix(manual_conf_matrix, "Manual Naive Bayes Confusion Matrix")
    manual_nb_scores = [manual_precision, manual_recall, manual_f1, manual_accuracy]
    plot_results(manual_nb_scores,"Manual Naive Bayes")

    # Scikit-learn Naive Bayes
    sklearn_accuracy, sklearn_conf_matrix, sklearn_precision, sklearn_recall, sklearn_f1 = evaluate_sklearn_nb(train_matrix, train_classes, test_matrix, test_classes)
    # print("Scikit-learn Naive Bayes Accuracy:", sklearn_accuracy)
    plot_confusion_matrix(sklearn_conf_matrix, "Scikit-learn Naive Bayes Confusion Matrix")
    sklearn_nb_scores = [sklearn_precision, sklearn_recall, sklearn_f1, sklearn_accuracy]
    plot_results(sklearn_nb_scores,"Scikit-learn Naive Bayes")

    # Save results
    write_scores_to_file(sklearn_accuracy,sklearn_precision,sklearn_recall,sklearn_f1,sklearn_conf_matrix,"NBMB_scikit.txt")
    write_scores_to_file(manual_accuracy,manual_precision,manual_recall,manual_f1,manual_conf_matrix,"NBMB_manual.txt")

if __name__ == "__main__":
    main()