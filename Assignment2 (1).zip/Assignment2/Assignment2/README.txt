Requirements:
    1) Python 3 or higher
    2) Python virtual environment. Follow the link for reference (https://uoa-eresearch.github.io/eresearch-cookbook/recipe/2014/11/26/python-virtual-env/)

Run Project:
    1) Activate venv using below command:
        source venv/bin/activate
    2) Install the required pacakges using below command:
        pip install -r requirements.txt
    3) Run below command to run the code or assignment:
        python3 assignment2.py
